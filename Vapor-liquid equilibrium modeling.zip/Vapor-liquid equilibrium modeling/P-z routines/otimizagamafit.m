clc
clear

% x0 = [2777        -117.1      1606        3121        170.9       2601];  % Valores extraídos do ddbst e usados como chute inicial
x0 = [986.5 -450.4 156.4 -817.7 -34.36 1913]; %verdadeiros UNIFAC original

% x0 = [2.7475e+03	-98.1639	1.8917e+03	5.1904e+03	136.3698	1.7360e+03];  %UNIFAC 278 K
% x0 = [2597.01390316500	-10.7653077091811	993.265583237400	1493.10760944539	18.8685688519252	1879.34324624799];  %UNIFAC 293 K
% x0 = [273.0309	-98.9921	2.1251e+03	561.5184	154.2137	1.4366e+03];  %UNIFAC 308 K
% x0 = [12035.2318884020	-40.3810616549404	302.988548750094	957.332478725006	6.51898202544374	1848.10500531005];  %UNIFAC 313 K
% x0 = [2092.74810886635	-94.0969262331637	3122.65525236437	2815.80554204437	115.585591727926	1590.52921796543];  %UNIFAC 323 K
% x0 = [3391.80969645394	-100.733300648534	1628.51834336167	5032.23661152689	116.814230583082	1545.39644358644];  %UNIFAC 338 K

% x0 = [5881.43329873157	-13.3293737741442	6923.39554242239    344.244297934066	75.0693793940056	1634.23774884719];   % Melhor parâmetro otimizado sem DORTMUND
% x0 = [2777        -117.1      1606        3121        170.9       2601       -4.674       0.001551       0.5481       -0.00098       -4.746       0.0009181       -13.69       0.01446       -0.8062       0.001291       -1.25       -0.006309]; %Parâmetros com Dortmund

% x0 = [-259.201195823429	-31.5278573093879	2729.82558393674	0.198471075307265	0.00405154795787279	-2.36767176851866	-0.00530418122601359]; %Parâmetros obtidos na abordagem simétrica
% x0 =[1355.81484324797	-50.0063243439441	5730.60939591860	-2.23206202874035	-0.000107930262811864	0.558989710693677	-0.00133242418288567	-17.9527920015335	0.0157178605460621]; % Valores otimizados; Abordagem simétrica; Incluído efeito da temp. no (1,4) e (2,4)


xf=x0;



% [xf]=fminsearch(@fotimizagamafi,x0)



%calculando o diagrama de fases com o valor de xf
t=338.15;
ncomp=2;

load dadoselv338.txt
load lambda.txt
load tcpcw.txt
load mrq.txt
vlambda=lambda;
vtcpcw=tcpcw;
dadoselv=dadoselv338;

[z1calc,ycalcpr,pbcalcpr,pexp,z1exp,yexp]=calcdiagpb(t,ncomp,dadoselv,vtcpcw,vlambda,mrq,xf);

% [drlp, drly] = desvrelmed(t,ncomp,dadoselv,vtcpcw,vlambda,x0);

npcalc=length(z1calc);
xc=linspace(0,1,npcalc);
yc=xc;

figure(1)
plot(z1calc,pbcalcpr./1000,'r',ycalcpr,pbcalcpr./1000,'b',z1exp,pexp./1000,'m*',yexp,pexp./1000,'b*')
ylabel('P(kPa)')
xlabel('ZA')
xlim([0 1])
% legend('bolha calc - PR', 'orvalho calc - PR','bolha exp','orvalho exp')

figure(2)
plot(z1calc,ycalcpr,'b',z1exp,yexp,'r*',xc,yc,'k')
ylabel('yA')
xlabel('xA')
legend('PR','Dados exp')

% desvrelp = drlp*100;
% desvrelz = drly*100;

% desvrelp = drlp/1e5;