function [gama]=calcgamauni2(x10,x20,t,mrq,x0)
lngamacomb=zeros(2,1);
lngamares=zeros(2,1);
gama=zeros(2,1);
fi=zeros(2,1);
teta=zeros(2,1);
tal=zeros(2,1);
l=zeros(2,1);

%número de primeiros vizinhos da rede
zconf=9;

%parâmetros uniquac - r e q
%ciclo-exano(1)/etanol(2)
r1=mrq(1,1);
q1=mrq(1,2);
r2=mrq(2,1);
q2=mrq(2,2);

%frações de segmentos
fi(1)=(r1*x10)/(r1*x10+r2*x20);
fi(2)=(r2*x20)/(r1*x10+r2*x20);

%frações de área de contato
teta(1)=(q1*x10)/(q1*x10+q2*x20);   
teta(2)=(q2*x20)/(q1*x10+q2*x20);

l(1)=(zconf/2)*(r1-q1)-(r1-1);
l(2)=(zconf/2)*(r2-q2)-(r2-1);

% %parâmetros energéticos uniquac - uij e uji
% u12=x0(1);
% u11=x0(2);
% u22=x0(3);
% %cálculo de wij e wji
% w21=u12-u11;
% w12=u12-u22;
% w12 = x0(1);
% w21 = x0(2);
% 
% tal(1)=exp(-w12/t);
% tal(2)=exp(-w21/t);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%cálculo dos coeficientes de atividade
%lngama=lngamacomb + lngamares
lngamacomb(1)=log(fi(1)/x10)-zconf/2*q1*log(fi(1)/teta(1))+l(1)-fi(1)/x10*(x10*l(1)+x20*l(2));
lngamacomb(2)=log(fi(2)/x20)-zconf/2*q2*log(fi(2)/teta(2))+l(2)-fi(2)/x20*(x10*l(1)+x20*l(2));
[lngamares(1),lngamares(2)]=calclngamares(t,x20,x10,x0);
% lngamares(1)=q1*(1-log(teta(1)+teta(2)*tal(2))-(teta(1)/(teta(1)+teta(2)*tal(2))+(teta(2)*tal(1))/(teta(1)*tal(1)+teta(2))));
% lngamares(2)=q2*(1-log(teta(1)*tal(1)+teta(2))-((teta(1)*tal(2))/(teta(1)+teta(2)*tal(2))+(teta(2)/(teta(1)*tal(1)+teta(2)))));
gama(1)=exp(lngamacomb(1)+lngamares(1));
gama(2)=exp(lngamacomb(2)+lngamares(2));
end