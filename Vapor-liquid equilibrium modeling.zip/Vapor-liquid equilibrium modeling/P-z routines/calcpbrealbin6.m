function [pb,y]=calcpbrealbin6(z,t,pv,fsat,vtcpc,vlambda,mrq,x0)
ncomp=2;
eps=1e-5;
epsy=1e-5;
dy=1;
dgama1=1;
dgama2=1;

yid=zeros(ncomp,1);

%lei de Rault
pb0=z(1)*pv(1)+z(2)*pv(2);
for i=1:ncomp
    yid(i)=z(i)*pv(i)/pb0;
end

y10=yid(1);
y20=yid(2);

%cálculo de coeficientes de atividade via UNIQUAC
% [gama]=calcgamauni(z(1),z(2),t,mrq,x0);
[gama]=calcgamauni2(z(1),z(2),t,mrq,x0);

while dy>=epsy
[zv,ai,bi]=calculazv(z(1),z(2),t,pb0,vtcpc,vlambda);
while dgama1>=eps||dgama2>=eps
      [coefug]=calcoefug6(y10,y20,zv,ai,bi,t,pb0); 

      %y2=y20*rgama2
      rgama2=(z(2)*gama(2)*fsat(2))/(y20*pb0*coefug(2));
      dgama2=(rgama2-1)^2;
      y2=y20*rgama2;
      y20=y2;

%       [coefug]=calcoefug6(y10,y20,zv,ai,bi,t,pb0); 

      %y1=y10*rgama1
      rgama1=(z(1)*gama(1)*fsat(1))/(y10*pb0*coefug(1));
      dgama1=(rgama1-1)^2;
      y1=y10*rgama1;
      y10=y1;
end
s=(y10+y20);
pb0=pb0*s;
dy=abs(s-1);
y=[y10,y20];
% y10=yid(1);
% y20=yid(2);
dgama1=1;
dgama2=1;
end
pb=pb0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [gama]=calcgamauni(x10,x20,t,mrq,x0)
lngamacomb=zeros(2,1);
lngamares=zeros(2,1);
gama=zeros(2,1);
fi=zeros(2,1);
teta=zeros(2,1);
tal=zeros(2,1);
l=zeros(2,1);
u=zeros(2,1);

%número de primeiros vizinhos da rede
zconf=9;

%parâmetros uniquac - r e q
%ciclo-exano(1)/etanol(2)
r1=mrq(1,1);
q1=mrq(1,2);
r2=mrq(2,1);
q2=mrq(2,2);

%frações de segmentos
fi(1)=(r1*x10)/(r1*x10+r2*x20);
fi(2)=(r2*x20)/(r1*x10+r2*x20);

%frações de área de contato
teta(1)=(q1*x10)/(q1*x10+q2*x20);   
teta(2)=(q2*x20)/(q1*x10+q2*x20);

l(1)=(zconf/2)*(r1-q1)-(r1-1);
l(2)=(zconf/2)*(r2-q2)-(r2-1);

%parâmetros energéticos uniquac - uij e uji
u12_0=x0(1);
u21_0=x0(2);

u12_t=x0(3);
u21_t=x0(4);

%cálculo de wij e wji
u(1)=u12_0+u12_t*(t-298.15);
u(2)=u21_0+u21_t*(t-298.15);

tal(1)=exp(-u(1)/t);
tal(2)=exp(-u(2)/t);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%cálculo dos coeficientes de atividade
%lngama=lngamacomb + lngamares
lngamacomb(1)=log(fi(1)/x10)-zconf/2*q1*log(fi(1)/teta(1))+l(1)-fi(1)/x10*(x10*l(1)+x20*l(2));
lngamacomb(2)=log(fi(2)/x20)-zconf/2*q2*log(fi(2)/teta(2))+l(2)-fi(2)/x20*(x10*l(1)+x20*l(2));
lngamares(1)=q1*(1-log(teta(1)+teta(2)*tal(2))-(teta(1)/(teta(1)+teta(2)*tal(2))+(teta(2)*tal(1))/(teta(1)*tal(1)+teta(2))));
lngamares(2)=q2*(1-log(teta(1)*tal(1)+teta(2))-((teta(1)*tal(2))/(teta(1)+teta(2)*tal(2))+(teta(2)/(teta(1)*tal(1)+teta(2)))));
gama(1)=exp(lngamacomb(1)+lngamares(1));
gama(2)=exp(lngamacomb(2)+lngamares(2));
end