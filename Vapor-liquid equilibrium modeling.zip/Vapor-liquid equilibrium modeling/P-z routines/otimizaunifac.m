% Rotina para otimizar os parâmetros do UNIFAC em todas as temperaturas ao
% mesmo tempo

% Data de criação: 28/04/2024

tic
clc
clear
close all

%% Define as variáveis
load dadoselv278m.txt
load dadoselv293m.txt
load dadoselv308m.txt
load dadoselv313m.txt
load dadoselv323m.txt
load dadoselv338m.txt

global ncomp
ncomp = 2;

global xexp
xexp = zeros(9,6);
xexp(1:7,1) = dadoselv278m(:,2);
xexp(1:7,2) = dadoselv293m(:,2);
xexp(1:7,3) = dadoselv308m(:,2);
xexp(1:9,4) = dadoselv313m(:,2);
xexp(1:7,5) = dadoselv323m(:,2);
xexp(1:7,6) = dadoselv338m(:,2);

global pexp
pexp = zeros(9,6);
pexp(1:7,1) = dadoselv278m(:,1);
pexp(1:7,2) = dadoselv293m(:,1);
pexp(1:7,3) = dadoselv308m(:,1);
pexp(1:9,4) = dadoselv313m(:,1);
pexp(1:7,5) = dadoselv323m(:,1);
pexp(1:7,6) = dadoselv338m(:,1);
pexp=pexp.*1000;

global yexp
yexp = zeros(9,6);
yexp(1:7,1) = dadoselv278m(:,3);
yexp(1:7,2) = dadoselv293m(:,3);
yexp(1:7,3) = dadoselv308m(:,3);
yexp(1:9,4) = dadoselv313m(:,3);
yexp(1:7,5) = dadoselv323m(:,3);
yexp(1:7,6) = dadoselv338m(:,3);

global pbcalc
pbcalc = zeros(9,1);

global ycalc
ycalc = zeros(9,1);

%% Otimização com fminsearch
% x0 =[-216.887814717893	-23.8381587785603	2601.86537835499	-0.0312679679929074	0.00527284985895723	0.0154075710408166	-0.0108734325973832];
% x0 =[2777 -117.1 3121 -4.674 0.001551 0.5481 -0.00098 -13.69 0.01446]; % Valores do ddbst; Abordagem simétrica; Incluído efeito da temp. no (1,4) e (2,4)
% x0 =[1355.81484324797	-50.0063243439441	5730.60939591860	-2.23206202874035	-0.000107930262811864	0.558989710693677	-0.00133242418288567	-17.9527920015335	0.0157178605460621]; % Valores otimizados; Abordagem simétrica; Incluído efeito da temp. no (1,4) e (2,4)
% x0 =[2777 -117.1 1606 3121 2601 -4.674 0.001551 -13.69 0.01446 -1.25 -0.006309]; % Valores do ddbst; 3ª Abordagem simétrica
x0 =[18893.5826719430	4.64508415748277	13053.3439218501	12337.5173835677	3580.65289881573	2.89810067572592	-0.000188743451002309	57.3260298908883	-0.0620753924675264	2.54805396484022	-0.0267102459500877]; % Valores otimizados; 3ª abordagem simétrica

% x0 = [0 0 0 0 0 0 0 0 0 0 0];
% x0 = [78.6916305613263	-6.83363383604144	-39.9768968745887	-16.2944853435607	89.3300035921228	-14.3633045272020	0.0217047089299539	1.18131146728422	-0.00265848361758087	-0.651878888320786	-0.00763647008735903];

% x0 = [1000 -20 500 300 -200 50 160 -230 480 30 40];
[xf] = fminsearch(@fotimizaunifac,x0);
disp(xf);
toc

function [fobj] = fotimizaunifac(x0)
%número de componentes
global ncomp
%load dos lambdas, tcpcw e mrq
load lambda.txt
load tcpcw.txt
load mrq.txt

%alocando parâmetros em variáveis pertinentes
global xexp
global pexp
global yexp
global pbcalc
global ycalc
vlambda=lambda;
vtcpcw=tcpcw;

%temperatura de equilíbrio
t=[278.15, 293.15, 308.15, 313.15, 323.15, 338.15];

fobj = 0;
for i = 1:6
    [pv,fsat] = calcpsat(t(i),ncomp,vtcpcw,vlambda);
    if i ~= 4
        for j = 1:7
            z=[xexp(j,i),1-xexp(j,i)];
            [pbcalc(j),y]=calcpbrealbin6(z,t(i),pv,fsat,vtcpcw,vlambda,mrq,x0);
            ycalc(j)=y(1);
        end
        for j = 1:7
            fobj = fobj + (abs(pexp(j,i) - pbcalc(j))/pexp(j,i)) + (abs(yexp(j,i) - ycalc(j))/yexp(j,i));
        end
    else
        for j = 1:9
            z=[xexp(j,i),1-xexp(j,i)];
            [pbcalc(j),y]=calcpbrealbin6(z,t(i),pv,fsat,vtcpcw,vlambda,mrq,x0);
            ycalc(j)=y(1);
        end
        for j = 1:9
            fobj = fobj + (abs(pexp(j,i) - pbcalc(j))/pexp(j,i)) + (abs(yexp(j,i) - ycalc(j))/yexp(j,i));
        end
    end
end
fprintf('fobj = %d\n',fobj);
end

function [psat,fsat]=calcpsat(t,ncomp,vtcpcw,vlambda)
palfa=vlambda;
tc=vtcpcw(:,1);
pc=vtcpcw(:,2);

psat=zeros(ncomp,1);
fsat=zeros(ncomp,1);
a=zeros(ncomp,1);
b=zeros(ncomp,1);

for k=1:ncomp
    [a(k),b(k)]=calcabpr2(t,tc(k),pc(k),palfa(k,:));
end

chute0=1*10^5;

for i=1:ncomp
    [psat(i),fsat(i)]=calculaelvfipr(t,a(i),b(i),chute0);
end
end

function [a,b]=calcabpr2(t,tc,pc,palfa)
r=8.314;
ac=0.45724*((r*tc)^2)/pc;
b=0.0778*r*tc/pc;
tr=t/tc;
alfat=exp(palfa(1)*(1-tr)*(abs(1-tr)^(palfa(2)-1))+palfa(3)*(1/tr-1));
a=ac*alfat;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [plv,fv]=calculaelvfipr(t,a,b,chute0)
r=8.3145;
[zl,zv,A,B]=resolveeospr(a,b,t,chute0);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fiv/fil;
dfi=1-rfi;
tol=1e-14;
while abs(dfi)>=tol
chute1=chute0*fil/fiv;
[zl,zv,A,B]=resolveeospr(a,b,t,chute1);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fiv/fil;
dfi=1-rfi;
chute0=chute1;
end
plv=chute0;
fv=plv*fiv;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [fiv,fil]=calcfipr(A,B,zl,zv)
fil=exp(zl-1-log(zl-B)+(A/(B*(2^1.5)))*log((zl+B*(1-2^0.5))/(zl+B*(1+2^0.5))));
fiv=exp(zv-1-log(zv-B)+(A/(B*(2^1.5)))*log((zv+B*(1-2^0.5))/(zv+B*(1+2^0.5))));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [zl,zv,A,B]=resolveeospr(a,b,t,chute)
r=8.314;
A=a*chute/(r*t)^2;
B=b*chute/(r*t);
alfa=-1+B;
beta=A-3*(B^2)-2*B;
gama=-A*B+B^2+B^3;
c=[1 alfa beta gama];
[solz]=roots(c);
zl=min(solz);
zv=max(solz);
end