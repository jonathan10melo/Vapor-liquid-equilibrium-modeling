function [fobj]=fotimizagamafi(x0)
%número de componentes
ncomp=2;
%load dos dados experimentais
load dadoselv338m.txt
load lambda.txt
load tcpcw.txt
load mrq.txt

%alocando parâmetros em variáveis pertinentes
dexp=dadoselv338m;
pexp=dexp(:,1)*1000;
yexp=dexp(:,3);
xexp=dexp(:,2);
vlambda=lambda;
vtcpcw=tcpcw;

%temperatura de equilíbrio
t=338.15;

nexp=length(pexp);
pbcalc=zeros(nexp,1);
ycalc=zeros(nexp,1);

[pv,fsat] = calcpsat(t,ncomp,vtcpcw,vlambda);

%calculando a pressão de bolha
for k=1:nexp
z=[xexp(k),1-xexp(k)];
[pbcalc(k),y]=calcpbrealbin6(z,t,pv,fsat,vtcpcw,vlambda,mrq,x0);
ycalc(k)=y(1);
end

%zerando a função objetivo
fobj=0;

for k=1:nexp
   fobj=fobj+abs(yexp(k)-ycalc(k))/yexp(k)+abs(pexp(k)-pbcalc(k))/pexp(k); 
end
disp(fobj)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [psat,fsat]=calcpsat(t,ncomp,vtcpcw,vlambda)
palfa=vlambda;
tc=vtcpcw(:,1);
pc=vtcpcw(:,2);

psat=zeros(ncomp,1);
fsat=zeros(ncomp,1);
a=zeros(ncomp,1);
b=zeros(ncomp,1);

for k=1:ncomp
    [a(k),b(k)]=calcabpr2(t,tc(k),pc(k),palfa(k,:));
end

chute0=1*10^5;

for i=1:ncomp
    [psat(i),fsat(i)]=calculaelvfipr(t,a(i),b(i),chute0);
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [a,b]=calcabpr2(t,tc,pc,palfa)
r=8.314;
ac=0.45724*((r*tc)^2)/pc;
b=0.0778*r*tc/pc;
tr=t/tc;
alfat=exp(palfa(1)*(1-tr)*(abs(1-tr)^(palfa(2)-1))+palfa(3)*(1/tr-1));
a=ac*alfat;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [plv,fv]=calculaelvfipr(t,a,b,chute0)
r=8.3145;
[zl,zv,A,B]=resolveeospr(a,b,t,chute0);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fiv/fil;
dfi=1-rfi;
tol=1e-14;
while abs(dfi)>=tol
chute1=chute0*fil/fiv;
[zl,zv,A,B]=resolveeospr(a,b,t,chute1);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fiv/fil;
dfi=1-rfi;
chute0=chute1;
end
plv=chute0;
fv=plv*fiv;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [fiv,fil]=calcfipr(A,B,zl,zv)
fil=exp(zl-1-log(zl-B)+(A/(B*(2^1.5)))*log((zl+B*(1-2^0.5))/(zl+B*(1+2^0.5))));
fiv=exp(zv-1-log(zv-B)+(A/(B*(2^1.5)))*log((zv+B*(1-2^0.5))/(zv+B*(1+2^0.5))));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [zl,zv,A,B]=resolveeospr(a,b,t,chute)
r=8.314;
A=a*chute/(r*t)^2;
B=b*chute/(r*t);
alfa=-1+B;
beta=A-3*(B^2)-2*B;
gama=-A*B+B^2+B^3;
c=[1 alfa beta gama];
[solz]=roots(c);
zl=min(solz);
zv=max(solz);
end