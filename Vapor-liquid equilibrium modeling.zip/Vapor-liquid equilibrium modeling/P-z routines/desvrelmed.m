function [ drlp, drly ] = desvrelmed(t,ncomp,dadoselv,vtcpcw,vlambda,x0)

load mrq.txt

[pv,fsat] = calcpsat(t,ncomp,vtcpcw,vlambda);

z1exp=dadoselv(:,2);
yexp=dadoselv(:,3);
pexp=dadoselv(:,1);

nexp = length(pexp);

drlp = 0;
drly = 0;

pcalc=zeros(nexp,1);
ycalc = zeros(nexp,1);

% z1calc = [0, 0.0918, 0.2452, 0.3929, 0.5080, 0.6142, 0.7519, 0.9041, 1];        %(278K)%
% z1calc = [0, 0.0910, 0.2441, 0.3920, 0.5077, 0.6138, 0.7524, 0.9045, 1];        %(293K)% 
% z1calc = [0, 0.0899, 0.2429, 0.3912, 0.5075, 0.6175, 0.7534, 0.9061, 1];        %(308K)% 
% z1calc = [0, 0.053, 0.113, 0.191, 0.353, 0.493, 0.596, 0.721, 0.802,0.918, 1];  %(313K)% 
z1calc = [0, 0.0886, 0.2413, 0.3903, 0.5072, 0.6148, 0.7555, 0.9094, 1];        %(323K)% 
% z1calc = [0, 0.0874, 0.2395, 0.3894, 0.5076, 0.6166, 0.7589, 0.9142, 1];        %(338)% 
z2calc = 1 - z1calc;

pexp=pexp.*1e3;

for i = 1:nexp
    if (i > 1) && (i < nexp)
       z = [z1calc(i),z2calc(i)]; 
       [pcalc(i),y0]=calcpbrealbin6(z,t,pv,fsat,vtcpcw,vlambda,mrq,x0);
       ycalc(i) = y0(1);
       % drlp = drlp + abs(pexp(i) - pcalc(i))/(pexp(i));
       % drly = drly + abs(yexp(i) - ycalc(i))/(yexp(i));
       drlp = drlp + abs(pexp(i) - pcalc(i));
       drly = drly + abs(yexp(i) - ycalc(i));
    elseif (i == 1)
       pcalc(i) = pv(2);
       ycalc(i) = 0;
    else
       pcalc(i) = pv(1);
       ycalc(i) = 1;
    end
    disp(i)
end
drlp = drlp/7;
drly = drly/7;
% drlp = drlp/9;
% drly = drly/9;
end

function [psat,fsat]=calcpsat(t,ncomp,vtcpc,vlambda)
palfa=vlambda;
tc=vtcpc(:,1);
pc=vtcpc(:,2);

psat=zeros(ncomp,1);
fsat=zeros(ncomp,1);
a=zeros(ncomp,1);
b=zeros(ncomp,1);

for k=1:ncomp
    [a(k),b(k)]=calcabpr2(t,tc(k),pc(k),palfa(k,:));
end

%chute inicial universal
chute0=1E5;

for i=1:ncomp
    [psat(i),fsat(i)]=calculaelvfipr(t,a(i),b(i),chute0);
end
end

function [a,b]=calcabpr2(t,tc,pc,palfa)
r=8.314;
ac=0.45724*((r*tc)^2)/pc;
b=0.0778*r*tc/pc;
%kw=0.37464+1.5422*w-0.26992*(w^2);
tr=t/tc;
alfat=exp(palfa(1)*(1-tr)*(abs(1-tr)^(palfa(2)-1))+palfa(3)*(1/tr-1));
%alfat=(1+kw*(1-tr^0.5))^2;
a=ac*alfat;
end

function [plv,fv,vv,vl,it]=calculaelvfipr(t,a,b,chute0)
r=8.3145;
[zl,zv,A,B]=resolveeospr(a,b,t,chute0);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fiv/fil;
dfi=1-rfi;
tol=1e-14;
it=0;
while abs(dfi)>=tol
chute1=chute0*fil/fiv;
it=it+1;
[zl,zv,A,B]=resolveeospr(a,b,t,chute1);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fiv/fil;
dfi=1-rfi;
chute0=chute1;
end
plv=chute0;
vv=r*t*zv/plv;
vl=r*t*zl/plv;
fv=plv*fiv;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [fiv,fil]=calcfipr(A,B,zl,zv)
fil=exp(zl-1-log(zl-B)+(A/(B*(2^1.5)))*log((zl+B*(1-2^0.5))/(zl+B*(1+2^0.5))));
fiv=exp(zv-1-log(zv-B)+(A/(B*(2^1.5)))*log((zv+B*(1-2^0.5))/(zv+B*(1+2^0.5))));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [zl,zv,A,B]=resolveeospr(a,b,t,chute)
r=8.314;
A=a*chute/(r*t)^2;
B=b*chute/(r*t);
alfa=-1+B;
beta=A-3*(B^2)-2*B;
gama=-A*B+B^2+B^3;
[solz]=resolvepolz(alfa,beta,gama);
[zl,zv]=escolhez(solz);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [solz]=resolvepolz(alfa,beta,gama)
syms x;
eq=x^3+alfa*(x^2)+beta*x+gama==0;
solz=vpasolve(eq,x);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [zl,zv]=escolhez(solz)
nz=length(solz);
nzf=0;
for k=1:nz
    l=isreal(solz(k));
    if l==1
        nzf=nzf+1;
    else
    end
end
solzf=zeros(nzf,1);
k=0;
for j=1:nz
    l=isreal(solz(j));
    if l==1
        k=k+1;
        solzf(k)=solz(j);
    else
    end
end
if nzf==1
zl=solzf(1);
zv=zl;
else
zl=min(solzf);
zv=max(solzf);
end
end