function [fobj]=fobjcalclambda(x0)
fobj=0;

% %H2O
load psath2o.txt
load tcpch2o.txt
tcpc=tcpch2o;
psate=psath2o;

%Acetona
% load psatacetona.txt
% load tcpcacetona.txt
% tcpc=tcpcacetona;
% psate=psatacetona;

texp=psate(:,1);
pexp=psate(:,2)*1E3;
nexp=length(texp);

[apr,bpr]=calcabpr(texp,tcpc(1),tcpc(2),x0);

for j=1:nexp
    chutepsat=pexp(j);
    psatcalc=calculaelvfipr(texp(j),apr(j),bpr,chutepsat);
    fobj = fobj + abs(psatcalc-pexp(j))/pexp(j);
end
disp(fobj)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [plv]=calculaelvfipr(t,a,b,chute0)
[zl,zv,A,B]=resolveeospr(a,b,t,chute0);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fiv/fil;
dfi=1-rfi;
tol=1e-5;
it=0;
while abs(dfi)>=tol
chute1=chute0/(rfi);
it=it+1;
[zl,zv,A,B]=resolveeospr(a,b,t,chute1);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fiv/fil;
dfi=1-rfi;
chute0=chute1;
end
plv=chute0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [a,b]=calcabpr(t,tc,pc,vl)
r=8.31451;
ac=0.45724*((r*tc)^2)/pc;
b=0.0778*r*tc/pc;
nc=length(t);
a=zeros(nc,1);
imodel=1;
for k=1:nc
tr=t(k)/tc;
if imodel==1
% alfa=exp(vl(1)*(1-tr)*(abs(1-tr)^vl(2)+vl(3)*(1/tr-1)));
alfa=exp(vl(1)*(1-tr)*(abs(1-tr)^(vl(2)-1))+vl(3)*(1/tr-1));
elseif imodel==2
dtr=1-tr^0.5;
alfa=(1+vl(1)*dtr+vl(2)*dtr^2+vl(3)*dtr^4)^2;
elseif imodel==3
alfa=1+vl(1)*(1-tr)+vl(2)*(1-tr^2)+vl(3)*(1-tr^3);
elseif imodel==4
alfa= exp(vl(1)*(1-tr)+2*vl(2)*log(1+vl(3)*(1-tr^0.5)));
end
a(k)=ac*alfa;
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [zl,zv,A,B]=resolveeospr(a,b,t,chute)
r=8.31451;
A=a*chute/(r*t)^2;
B=b*chute/(r*t);
alfa=-1+B;
beta=A-3*(B^2)-2*B;
gama=-A*B+B^2+B^3;
c=[1 alfa beta gama];
[solz]=roots(c);
zl=min(solz);
zv=max(solz);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [fiv,fil]=calcfipr(A,B,zl,zv)
fil=exp(zl-1-log(zl-B)+(A/(B*(2^1.5)))*log((zl+B*(1-2^0.5))/(zl+B*(1+2^0.5))));
fiv=exp(zv-1-log(zv-B)+(A/(B*(2^1.5)))*log((zv+B*(1-2^0.5))/(zv+B*(1+2^0.5))));
end

