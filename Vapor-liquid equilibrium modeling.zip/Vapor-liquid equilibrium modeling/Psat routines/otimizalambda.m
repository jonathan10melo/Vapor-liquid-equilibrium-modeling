clear
clc

%chute inicial para os parâmetros da função alfa
x0 = [0.5986 1.0053 0.0799]; %ciclohexano
% x0=[1.6105 1.0790 -0.1457]; %etanol
xf=x0;

%otimização com o algoritmo Simplex
% [xf]=fminsearch(@fobjcalclambda,x0)

%ciclohexano
load psatciclohexanoRefprop.txt
load tcpcciclohexano.txt
tcpc=tcpcciclohexano;
psate=psatciclohexanoRefprop;

%etanol
% load psatetanolRefprop.txt
% load tcpcetanol.txt
% tcpc=tcpcetanol;
% psate=psatetanolRefprop;

%armazenando valores de temperatura e pressão de vapor experimentais
texp=psate(:,1);
pexp=psate(:,2)*1E5;

%definindo o vetor de pressões a ser calculado
nt=500;
nexp=length(texp);
pcalc=zeros(nt,1);

%definindo o vetor de temperaturas
tmin=min(texp);
tmax=max(texp);
tcalc=linspace(tmin,tmax,nt);
[apr,bpr]=calcabpr(tcalc,tcpc(1),tcpc(2),xf);

%valor inicial para o cálculo
chutepsat=pexp(1);

for j=1:nt
    pcalc(j)=calculaelvfipr(tcalc(j),apr(j),bpr,chutepsat);
    chutepsat=pcalc(j);
end

%diagram plot
figure(1)
plot(texp,pexp/1000,'rs',tcalc,pcalc/1000,'b')
xlabel('T (K)')
ylabel('Psat (kPa)')
% legend('Exp. data [1-8]; DDBST')
% legend('DDBST Daten')
legend('RefProp Data')

%error calculation and ploting
disp('relative error computation')
[apr,bpr]=calcabpr(texp,tcpc(1),tcpc(2),xf);
errorel=zeros(nexp,1);
chutepsat=pexp(1);

errom=0;

for j=1:nexp
psatmodel=calculaelvfipr(texp(j),apr(j),bpr,chutepsat);
chutepsat=psatmodel;
% errorel(j)=abs(psatmodel-pexp(j))/pexp(j);
errorel(j)=abs(psatmodel-pexp(j));
errom=errom+errorel(j);
end

%erro relativo médio
errom=errom/nexp

figure(2)
plot(texp,errorel,'b*')
xlabel('T(k)')
ylabel('Relative error in Psat')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [plv]=calculaelvfipr(t,a,b,chute0)
[zl,zv,A,B]=resolveeospr(a,b,t,chute0);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fiv/fil;
dfi=1-rfi;
tol=1e-5;
while abs(dfi)>=tol
chute1=chute0/(rfi);
[zl,zv,A,B]=resolveeospr(a,b,t,chute1);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fiv/fil;
dfi=1-rfi;
chute0=chute1;
end
plv=chute0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [a,b]=calcabpr(t,tc,pc,vl)
r=8.31451;
ac=0.45724*((r*tc)^2)/pc;
b=0.0778*r*tc/pc;
nc=length(t);
a=zeros(nc,1);
imodel=1;
for k=1:nc
tr=t(k)/tc;
if imodel==1
% alfa=exp(vl(1)*(1-tr)*(abs(1-tr)^vl(2)+vl(3)*(1/tr-1)));
alfa=exp(vl(1)*(1-tr)*(abs(1-tr)^(vl(2)-1))+vl(3)*(1/tr-1));
elseif imodel==2
dtr=1-tr^0.5;
alfa=(1+vl(1)*dtr+vl(2)*dtr^2+vl(3)*dtr^4)^2;
elseif imodel==3
alfa=1+vl(1)*(1-tr)+vl(2)*(1-tr^2)+vl(3)*(1-tr^3);
elseif imodel==4
alfa= exp(vl(1)*(1-tr)+2*vl(2)*log(1+vl(3)*(1-tr^0.5)));
end
a(k)=ac*alfa;
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [zl,zv,A,B]=resolveeospr(a,b,t,chute)
r=8.31451;
A=a*chute/(r*t)^2;
B=b*chute/(r*t);
alfa=-1+B;
beta=A-3*(B^2)-2*B;
gama=-A*B+B^2+B^3;
c=[1 alfa beta gama];
[solz]=roots(c);
zl=min(solz);
zv=max(solz);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [fiv,fil]=calcfipr(A,B,zl,zv)
fil=exp(zl-1-log(zl-B)+(A/(B*(2^1.5)))*log((zl+B*(1-2^0.5))/(zl+B*(1+2^0.5))));
fiv=exp(zv-1-log(zv-B)+(A/(B*(2^1.5)))*log((zv+B*(1-2^0.5))/(zv+B*(1+2^0.5))));
end
