function [zv,ai,bi]=calculazv(z1,z2,t,p,mlambda,mtcpc)
ncomp=2;
% d12=0;

tc=mtcpc(:,1);
pc=mtcpc(:,2);

ai=zeros(ncomp,1);
bi=zeros(ncomp,1);

for k=1:ncomp
   [ai(k),bi(k)]=calcabpr2(t,tc(k),pc(k),mlambda(k,:));
end

[A,B]=calcab(z1,z2,t,p,ai,bi);

[zv]=resolveeospr2(A,B);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [A,B,am,bm]=calcab(x1,x2,t,p,ai,bi)
r=8.314;
a12=(ai(1)*ai(2))^(1/2);
am=x1^2*ai(1)+2*x1*x2*a12+x2^2*ai(2); 
bm=x1*bi(1)+x2*bi(2);
A=am*p/(r*t)^2;
B=bm*p/(r*t);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [a,b]=calcabpr2(t,tc,pc,palfa)
r=8.31451;
ac=0.45724*((r*tc)^2)/pc;
b=0.0778*r*tc/pc;
tr=t/tc;
alfat=exp(palfa(1)*(1-tr)*(abs(1-tr)^(palfa(2)-1))+palfa(3)*(1/tr-1));
a=ac*alfat;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [zv]=resolveeospr2(A,B)
alfa=-1+B;
beta=A-3*(B^2)-2*B;
gama=-A*B+B^2+B^3;
c=[1,alfa,beta,gama];
solz=roots(c);
zv=max(solz);
end