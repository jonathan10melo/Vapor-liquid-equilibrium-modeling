function [tb,y]=calctbrealbin2(z,p,fsat,mrq,tchute,mlambda,mtcpc,x0)
ncomp=2;

%toler�ncia
eps=1e-5;

%vari�veis m�tricas computacionais
dy=1;
dgama1=1;
dgama2=1;

%acelerador de converg�ncia
lt=30;

yid=zeros(ncomp,1);

tb0=tchute;

load pantoine12.txt
pantoine=pantoine12;

%chute inicial para composi��o da fase vapor
for i=1:ncomp
    [psat] = calcpsatantoine(pantoine,tb0);
    yid(i)=z(i)*psat(i)/p;
end

%composi��o inicial da fase vapor
y10=yid(1);
y20=yid(2);

while dy>=eps
[gama]=calcgamauni2(z(1),z(2),tb0,mrq,x0);
while dgama1>=eps || dgama2>=eps    
      %c�lculo dos coeficientes de fugacidade para a fase vapor
      [zv,ai,bi]=calculazv(z(1),z(2),tb0,p,mlambda,mtcpc);
      [coefug]=calcoefugv(y10,y20,zv,ai,bi,tb0,p); 
      
      %atualiza��o de y2
      %y2=y20*rgama2;
      rgama2=(z(2)*gama(2)*fsat(2))/(y20*p*coefug(2));
      dgama2=(rgama2-1)^2;
      y2=(z(2)*gama(2)*fsat(2))/(p*coefug(2));
      y20=y2;
      
      %atualiza��o de y1
      %y1=y10*rgama1;
      [coefug]=calcoefugv(y10,y20,zv,ai,bi,tb0,p); 
      rgama1=(z(1)*gama(1)*fsat(1))/(y10*p*coefug(1));
      dgama1=(rgama1-1)^2;
      y1=(z(1)*gama(1)*fsat(1))/(p*coefug(1));
      y10=y1;
end
%atualiza��o da temperatura de bolha
sy=y10+y20;
dy=sy-1;
tb0=tb0-dy*lt;

%atualiza��o de psat e fsat
[fsat]=calcpsat2(tb0,ncomp,mlambda,mtcpc);

dy=abs(dy);
dgama1=1;
dgama2=1;
end
tb=tb0;
y=[y10,y20];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [psata] = calcpsatantoine(pa,t)
psata=zeros(2,1);
for k=1:2
    %do NIST
    a=pa(k,1);
    b=pa(k,2);
    c=pa(k,3);
    %press�o em bar
    psata(k)=10^(a-b/(t+c));
end
alfa=1E5;
%Convers�o de bar para pascal
psata=psata*alfa;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [fsat]=calcpsat2(t,ncomp,mlambda,mtcpc)
tc=mtcpc(:,1);
pc=mtcpc(:,2);

psat=zeros(ncomp,1);
fsat=zeros(ncomp,1);
a=zeros(ncomp,1);
b=zeros(ncomp,1);

for k=1:ncomp
    [a(k),b(k)]=calcabpr2(t,tc(k),pc(k),mlambda(k,:));
end
chute0=1*10^5;
for i=1:ncomp
    [psat(i),fsat(i)]=calculaelvfipr(t,a(i),b(i),chute0);
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [a,b]=calcabpr2(t,tc,pc,palfa)
r=8.314;
ac=0.45724*((r*tc)^2)/pc;
b=0.0778*r*tc/pc;
tr=t/tc;
alfat=exp(palfa(1)*(1-tr)*(abs(1-tr)^(palfa(2)-1))+palfa(3)*(1/tr-1));
a=ac*alfat;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [plv,fv]=calculaelvfipr(t,a,b,chute0)
[zl,zv,A,B]=resolveeospr(a,b,t,chute0);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fiv/fil;
dfi=1-rfi;
tol=1e-5;
while abs(dfi)>=tol
chute1=chute0*fil/fiv;
[zl,zv,A,B]=resolveeospr(a,b,t,chute1);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fiv/fil;
dfi=1-rfi;
chute0=chute1;
end
plv=chute0;
fv=plv*fiv;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [fiv,fil]=calcfipr(A,B,zl,zv)
fil=exp(zl-1-log(zl-B)+(A/(B*(2^1.5)))*log((zl+B*(1-2^0.5))/(zl+B*(1+2^0.5))));
fiv=exp(zv-1-log(zv-B)+(A/(B*(2^1.5)))*log((zv+B*(1-2^0.5))/(zv+B*(1+2^0.5))));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [zl,zv,A,B]=resolveeospr(a,b,t,chute)
r=8.314;
A=a*chute/(r*t)^2;
B=b*chute/(r*t);
alfa=-1+B;
beta=A-3*(B^2)-2*B;
gama=-A*B+B^2+B^3;
c=[1,alfa,beta,gama];
solz=roots(c);
zl=min(solz);
zv=max(solz);
end