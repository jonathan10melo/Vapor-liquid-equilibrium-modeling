clear
clc

%parâmetros otimizados para o modelo UNIFAC
% xf = [515.413180559716	-132.286937309503	5375.23273341953	1352.80925506462	158.483250982913	1552.4632132818];

% xf = [2777        -117.1      1606        3121        170.9       2601]; % UNIFAC do ddbst

xf = [5881.43329873157	-13.3293737741442	6923.39554242239    344.244297934066	75.0693793940056	1634.23774884719];    % Unifac Otimizado
% xf = [2777        -117.1      1606        3121        170.9       2601     -4.674       0.001551       0.5481       -0.00098       -4.746    0.0009181       -13.69       0.01446       -0.8062       0.001291     -1.25       -0.006309];    % UNIFAC Dortmund

% xf = [-259.201195823429	-31.5278573093879	2729.82558393674	0.198471075307265	0.00405154795787279	-2.36767176851866	-0.00530418122601359]; % Parâmetros otimizados na abordagem simétrica sem considerar (1,4) e (2,4) com efeito da temperatura

% xf =[1355.81484324797	-50.0063243439441	5730.60939591860	-2.23206202874035	-0.000107930262811864	0.558989710693677	-0.00133242418288567	-17.9527920015335	0.0157178605460621]; % Valores otimizados; Abordagem simétrica; Incluído efeito da temp. no (1,4) e (2,4)

% xf =[18893.5826719430	4.64508415748277	13053.3439218501	12337.5173835677	3580.65289881573	2.89810067572592	-0.000188743451002309	57.3260298908883	-0.0620753924675264	2.54805396484022	-0.0267102459500877]; % Valores otimizados; 3ª abordagem simétrica

% xf = [78.6916305613263	-6.83363383604144	-39.9768968745887	-16.2944853435607	89.3300035921228	-14.3633045272020	0.0217047089299539	1.18131146728422	-0.00265848361758087	-0.651878888320786	-0.00763647008735903]; % Valores otimizados; 3ª abordagem simétrica; Chute inicial diferente do ddbst

%pressão em bar em que o diagrama será calculado
% p=0.4;
p=0.6981;
% p=0.9772;
% p=1.013;
% p=1.5;

%desennho do diagrama de fases no espaço T x zA (p=cte)
% load dadoselv40kPa.txt
% texp=dadoselv40kPa(:,1);
% xexp=dadoselv40kPa(:,2);
% yexp=dadoselv40kPa(:,3);

load dadoselv69kPa.txt
texp=dadoselv69kPa(:,1);
xexp=dadoselv69kPa(:,2);
yexp=dadoselv69kPa(:,3);

% load dadoselv98kPa.txt
% texp=dadoselv98kPa(:,1);
% xexp=dadoselv98kPa(:,2);
% yexp=dadoselv98kPa(:,3);

% load dadoselv101_2kPa.txt
% texp=dadoselv101_2kPa(:,1);
% xexp=dadoselv101_2kPa(:,2);
% yexp=dadoselv101_2kPa(:,3);
% 
% load dadoselv101_3kPa.txt
% texp2=dadoselv101_3kPa(:,1);
% xexp2=dadoselv101_3kPa(:,2);
% yexp2=dadoselv101_3kPa(:,3);
% 
% load dadoselv101_4kPa.txt
% texp3=dadoselv101_4kPa(:,1);
% xexp3=dadoselv101_4kPa(:,2);
% yexp3=dadoselv101_4kPa(:,3);

% load dadoselv150kPa.txt
% texp=dadoselv150kPa(:,1);
% xexp=dadoselv150kPa(:,2);
% yexp=dadoselv150kPa(:,3);

%load de r e q dos componentes puros
load mrq.txt

%load dos parâmetros do ciclo-hexano
load paA.txt
load lambdaA.txt
load tcpcA.txt

%Temperatura de ebulição e fsat do componente 1
[tlv1,fsat1]=calculatlv(paA,tcpcA,lambdaA,p);

%load dos parâmetros da etanol
load paB.txt
load lambdaB.txt
load tcpcB.txt

%Temperatura de ebulição e fsat componente 2
[tlv2,fsat2]=calculatlv(paB,tcpcB,lambdaB,p);

%chute para t de bolha
tchute1=(tlv1+tlv2)/2;

%armazenando dados de lambda, tc e pc em matrizes
mlambda=[lambdaA;lambdaB];
mtcpc=[tcpcA;tcpcB];

%composição da mistura
np=350;
vzcalc=linspace(0.0000000001,0.99999999999,np);
tbcalc=zeros(np,1);
ycalc=zeros(np,1);
fsat=[fsat1,fsat2];

%cálculo das temperaturas de bolha em cada pressão de interesse
for k=1:np
zcalc=[vzcalc(k),1-vzcalc(k)]
[tbcalc(k),yb]=calctbrealbin2(zcalc,p*1e5,fsat,mrq,tchute1,mlambda,mtcpc,xf);
ycalc(k)=yb(1);
tchute1=tbcalc(k);
end

figure(1)
plot(vzcalc,tbcalc,'b',ycalc,tbcalc,'r',xexp,texp,'b*',yexp,texp,'r*')
% plot(vzcalc,tbcalc,'b',ycalc,tbcalc,'r',xexp,texp,'b*',yexp,texp,'r*',xexp2,texp2,'bs',yexp2,texp2,'rs',xexp3,texp3,'b+',yexp3,texp3,'r+')
xlabel('zA')
ylabel('T(K)')
% legend('Linha de bolha','linha de orvalho','location','best')

%% error calculation
% % load dadoselv40kPam.txt
% % texpm=dadoselv40kPam(:,1);
% % xexpm=dadoselv40kPam(:,2);
% % yexpm=dadoselv40kPam(:,3);
% 
% % load dadoselv69kPam.txt
% % texpm=dadoselv69kPam(:,1);
% % xexpm=dadoselv69kPam(:,2);
% % yexpm=dadoselv69kPam(:,3);
% 
% % load dadoselv98kPam.txt
% % texpm=dadoselv98kPam(:,1);
% % xexpm=dadoselv98kPam(:,2);
% % yexpm=dadoselv98kPam(:,3);
% 
% load dadoselv101_todoskPam.txt
% texpm=dadoselv101_todoskPam(:,1);
% xexpm=dadoselv101_todoskPam(:,2);
% yexpm=dadoselv101_todoskPam(:,3);
% 
% % load dadoselv150kPam.txt
% % texpm=dadoselv150kPam(:,1);
% % xexpm=dadoselv150kPam(:,2);
% % yexpm=dadoselv150kPam(:,3);
% 
% nexpm=length(xexpm);
% errotm=zeros(nexpm,1);
% erroym=zeros(nexpm,1);
% 
% for i=1:nexpm
% z=[xexpm(i),1-xexpm(i)]
% [tbcalc,yb]=calctbrealbin2(z,p*1e5,fsat,mrq,tchute1,mlambda,mtcpc,xf);
% % errotm(i)=abs(tbcalc-texpm(i))/texpm(i);
% % erroym(i)=abs(yb(1)-yexpm(i))/yexpm(i);
% errotm(i)=abs(tbcalc-texpm(i));
% erroym(i)=abs(yb(1)-yexpm(i));
% tchute1=tbcalc;
% end
% 
% figure(2)
% plot(xexpm,errotm,'bs')
% xlabel('zA')
% ylabel('erro Tb')
% 
% figure(3)
% plot(xexpm,erroym,'bs')
% xlabel('zA')
% ylabel('erro yA')
% 
% % desvrelt=(sum(errotm)/nexpm)*100;
% % desvrelz=(sum(erroym)/nexpm)*100;
% 
% desvrelt=sum(errotm)/nexpm;
% desvrelz=sum(erroym)/nexpm;