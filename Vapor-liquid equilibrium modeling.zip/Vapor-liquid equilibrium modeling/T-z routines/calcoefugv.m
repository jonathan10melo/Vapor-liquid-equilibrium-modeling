function [coefug]=calcoefugv(x1,x2,zv,ai,bi,t,p)
[A,B,am,bm]=calcab(x1,x2,t,p,ai,bi);
[coefug]=calcfipr(A,B,zv,ai,bi,am,bm,x1,x2);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [A,B,am,bm]=calcab(x1,x2,t,p,ai,bi)
r=8.314;
a12=(ai(1)*ai(2))^(1/2);
am=x1^2*ai(1)+2*x1*x2*a12+x2^2*ai(2); 
bm=x1*bi(1)+x2*bi(2);
A=am*p/(r*t)^2;
B=bm*p/(r*t);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [coefug]=calcfipr(A,B,z,ai,bi,a,b,x1,x2)
ncomp=2;
coefug=zeros(ncomp,1);

a12=(ai(1)*ai(2))^(1/2);

%componente 1
p11=(bi(1)/b)*(z-1)-log(z-B);
p12=A/(2*2^0.5*B);
p13=2*(x1*ai(1)+x2*a12)/a -bi(1)/b;
p14=log((z+(1+2^0.5)*B)/(z+(1-2^0.5)*B));
coefug(1)=exp(p11-p12*p13*p14);

%componente 2
p21=(bi(2)/b)*(z-1)-log(z-B);
p22=A/(2*2^0.5*B);
p23=2*(x1*a12+x2*ai(2))/a -bi(2)/b;
p24=log((z+(1+2^0.5)*B)/(z+(1-2^0.5)*B));
coefug(2)=exp(p21-p22*p23*p24);
end