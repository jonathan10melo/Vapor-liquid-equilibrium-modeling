function [lngamaresciclo, lngamaresetoh] = calclngamares(T,x10,x20,x0)

% x10 = fração molar do etanol
% x20 = fração molar do ciclohexano

%load amn.txt
load vmj.txt
load qsub.txt

%% UNIFAC otimizado
amn(1,3) = x0(1);
amn(2,3) = x0(1);
amn(1,4) = x0(2);
amn(2,4) = x0(2);
amn(3,1) = x0(3);
amn(3,2) = x0(3);
amn(3,4) = x0(4);
amn(4,1) = x0(5);
amn(4,2) = x0(5);
amn(4,3) = x0(6);

%% UNIFAC Dortmundo do ddbst
% amn(1,3) = x0(1)+x0(7)*T+x0(8)*T^2;
% amn(2,3) = x0(1)+x0(7)*T+x0(8)*T^2;
% amn(1,4) = x0(2)+x0(9)*T+x0(10)*T^2;
% amn(2,4) = x0(2)+x0(9)*T+x0(10)*T^2;
% amn(3,1) = x0(3)+x0(11)*T+x0(12)*T^2;
% amn(3,2) = x0(3)+x0(11)*T+x0(12)*T^2;
% amn(3,4) = x0(4)+x0(13)*T+x0(14)*T^2;
% amn(4,1) = x0(5)+x0(15)*T+x0(16)*T^2;
% amn(4,2) = x0(5)+x0(15)*T+x0(16)*T^2;
% amn(4,3) = x0(6)+x0(17)*T+x0(18)*T^2;

%% UNIFAC simétrico (com efeito da temperatura apenas nas interações com OH)
% amn(1,3) = x0(1)+x0(4)*T+x0(5)*T^2;
% amn(2,3) = x0(1)+x0(4)*T+x0(5)*T^2;
% amn(1,4) = x0(2);
% amn(2,4) = x0(2);
% amn(3,1) = amn(1,3);
% amn(3,2) = amn(2,3);
% amn(3,4) = x0(3)+x0(6)*T+x0(7)*T^2;
% amn(4,1) = amn(1,4);
% amn(4,2) = amn(2,4);
% amn(4,3) = amn(3,4);

%% UNIFAC simétrico (2ª abordagem com inclusão da temperatura no (1,4) e (2,4))
% amn(1,3) = x0(1)+x0(4)*T+x0(5)*T^2;
% amn(2,3) = x0(1)+x0(4)*T+x0(5)*T^2;
% amn(1,4) = x0(2)+x0(6)*T+x0(7)*T^2;
% amn(2,4) = x0(2)+x0(6)*T+x0(7)*T^2;
% amn(3,1) = amn(1,3);
% amn(3,2) = amn(2,3);
% amn(3,4) = x0(3)+x0(8)*T+x0(9)*T^2;
% amn(4,1) = amn(1,4);
% amn(4,2) = amn(2,4);
% amn(4,3) = amn(3,4);

%% UNIFAC simétrico (3ª abordagem)
% amn(1,3) = x0(1)+x0(6)*T+x0(7)*T^2;
% amn(2,3) = x0(1)+x0(6)*T+x0(7)*T^2;
% amn(1,4) = x0(2);
% amn(2,4) = x0(2);
% amn(3,1) = x0(3);
% amn(3,2) = x0(3);
% amn(3,4) = x0(4)+x0(8)*T+x0(9)*T^2;
% amn(4,1) = amn(1,4);
% amn(4,2) = amn(2,4);
% amn(4,3) = x0(5)+x0(10)*T+x0(11)*T^2;

nsub = length(vmj(:,1));

Psi=exp(-amn./T);

X = zeros(1,nsub);

denX = x10*sum(vmj(:,2))+x20*sum(vmj(:,1));

for i = 1:nsub
    X(i) = (vmj(i,2)*x10 + vmj(i,1)*x20)/denX;
end

fracGamao = zeros(1,nsub);

denTeta = sum(qsub.*X);

for i = 1:nsub
    Teta(i) = qsub(i)*X(i)/denTeta;
end

den = zeros(1,nsub);

for i = 1:nsub
    den(i) = sum(Teta.*transpose(Psi(:,i)));
end

for i = 1:nsub
    fracGamao(i) = Teta(i)./den(i);
    parcln(i) = log(sum(Teta.*transpose(Psi(:,i))));
end

for i = 1:nsub
    fracGamao2 = fracGamao.*Psi(i,:);
    parcfracao(i) = sum(fracGamao2);
end

for i = 1:nsub
    lnGamao(i) = qsub(i)*(1-parcln(i)-parcfracao(i));
end

% Uhuuuuul, terminamos a primeira parte

for i = 1:nsub
    Xciclo(i) = vmj(i,1)/sum(vmj(:,1));
    Xetoh(i) = vmj(i,2)/sum(vmj(:,2));
end

denTetaciclo = sum(qsub.*Xciclo);

for i = 1:nsub
    Tetaciclo(i) = qsub(i)*Xciclo(i)/denTetaciclo;
end

denTetaetoh = sum(qsub.*Xetoh);

for i = 1:nsub
    Tetaetoh(i) = qsub(i)*Xetoh(i)/denTetaetoh;
end

denciclo = zeros(1,nsub);

for i = 1:nsub
    denciclo(i) = sum(Tetaciclo.*transpose(Psi(:,i)));
end

for i = 1:nsub
    fracGamaociclo(i) = Tetaciclo(i)./denciclo(i);
    parclnciclo(i) = log(sum(Tetaciclo.*transpose(Psi(:,i))));
end

for i = 1:nsub
    fracGamao2ciclo = fracGamaociclo.*Psi(i,:);
    parcfracaociclo(i) = sum(fracGamao2ciclo);
end

for i = 1:nsub
    lnGamaociclo(i) = qsub(i)*(1-parclnciclo(i)-parcfracaociclo(i));
end

denetoh = zeros(1,nsub);

for i = 1:nsub
    denetoh(i) = sum(Tetaetoh.*transpose(Psi(:,i)));
end

for i = 1:nsub
    fracGamaoetoh(i) = Tetaetoh(i)./denetoh(i);
    parclnetoh(i) = log(sum(Tetaetoh.*transpose(Psi(:,i))));
end

for i = 1:nsub
    fracGamao2etoh = fracGamaoetoh.*Psi(i,:);
    parcfracaoetoh(i) = sum(fracGamao2etoh);
end

for i = 1:nsub
    lnGamaoetoh(i) = qsub(i)*(1-parclnetoh(i)-parcfracaoetoh(i));
end

% Uhuuul, fim da segunda parte

parcresciclo = transpose(vmj(:,1)).*(lnGamao - lnGamaociclo);
lngamaresciclo = sum(parcresciclo);

parcresetoh = transpose(vmj(:,2)).*(lnGamao - lnGamaoetoh);
lngamaresetoh = sum(parcresetoh);

end