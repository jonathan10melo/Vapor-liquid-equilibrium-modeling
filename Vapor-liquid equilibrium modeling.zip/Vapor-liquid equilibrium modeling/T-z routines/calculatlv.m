function [tlvf,fsat]=calculatlv(pa,tcpc,vlambda,p)
[tlvcalc]=calctsatantoine(pa,p);
[tlvcalc2,fsat]=calctsat(p*1e5,tlvcalc,tcpc,vlambda);
tlvf=tlvcalc2;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [tlv,fsat]=calctsat(p,tchute,tcpc,vlambda)
tc=tcpc(1);
pc=tcpc(2);
[tlv,fsat]=calculaelvfiprp2(p,tchute,tc,pc,vlambda);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [a,b]=calcabpr2(t,tc,pc,palfa)
r=8.314;
ac=0.45724*((r*tc)^2)/pc;
b=0.0778*r*tc/pc;
tr=t/tc;
alfat=exp(palfa(1)*(1-tr)*(abs(1-tr)^(palfa(2)-1))+palfa(3)*(1/tr-1));
a=ac*alfat;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [tsat,fv]=calculaelvfiprp2(p,tchute,tc,pc,palfa)
%calcula tsat do componente com base em um valor de pressão conhecido
[a,b]=calcabpr2(tchute,tc,pc,palfa);
[zl,zv,A,B]=resolveeospr(a,b,tchute,p);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fil/fiv;
dfi=1-rfi;
tol=1e-5;
lfi=10;
while abs(dfi)>=tol
tchute=tchute+dfi*lfi;
[a,b]=calcabpr2(tchute,tc,pc,palfa);
[zl,zv,A,B]=resolveeospr(a,b,tchute,p);
[fiv,fil]=calcfipr(A,B,zl,zv);
rfi=fil/fiv;
dfi=1-rfi;
end
tsat=tchute;
fv=p*fiv;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [fiv,fil]=calcfipr(A,B,zl,zv)
fil=exp(zl-1-log(zl-B)+(A/(B*(2^1.5)))*log((zl+B*(1-2^0.5))/(zl+B*(1+2^0.5))));
fiv=exp(zv-1-log(zv-B)+(A/(B*(2^1.5)))*log((zv+B*(1-2^0.5))/(zv+B*(1+2^0.5))));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [zl,zv,A,B]=resolveeospr(a,b,t,chute)
r=8.314;
A=a*chute/(r*t)^2;
B=b*chute/(r*t);
alfa=-1+B;
beta=A-3*(B^2)-2*B;
gama=-A*B+B^2+B^3;
c=[1,alfa,beta,gama];
solz=roots(c);
zl=min(solz);
zv=max(solz);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [tlv2]=calctsatantoine(pa,p)
a=pa(1);
b=pa(2);
c=pa(3);
tlv2=b/(a-log10(p))-c;
end